class MorseCodeTree {
    // manually build up the morse code tree
    constructor() {

    }

    // Accept an array of strings of dots and dashes.
    // Return the letters in the morse code tree associated
    // with the dots and dashes
    // decode(["...", "---", "..."]) => "SOS"
    // decode(["-.-.", ".-", "-"]) => "CAT"
    decode(message) {

    }
}
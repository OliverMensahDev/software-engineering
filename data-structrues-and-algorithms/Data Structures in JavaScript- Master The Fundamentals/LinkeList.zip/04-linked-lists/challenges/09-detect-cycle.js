// Return true or false depending on if the list has a cycle
// (any node that points back to a previous node in the list)
function hasCycle(list) {

}
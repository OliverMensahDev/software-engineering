// Accept a list with a .root property and return the sum
// of only node.data values at odd indexes.
function oddIndexSum(list) {

}
// Assume l1 and l2 are sorted ascending.
// Merge all the nodes of l2 into l1 and keep all nodes sorted.
function merge(l1, l2) {

}
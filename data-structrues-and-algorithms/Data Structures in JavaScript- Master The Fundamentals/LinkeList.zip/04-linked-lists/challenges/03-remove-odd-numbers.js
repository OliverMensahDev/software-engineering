// Accept a linked list and remove and nodes
// with odd-numbered data values
function removeOddNumbers(list) {

}
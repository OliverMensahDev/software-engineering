function peek(stack) {
    return stack[stack.length - 1]
}

function isBalanced(str) {
    let stack = []
    stack.push()
    stack.pop()
}
// Write a function that accepts an array of choices
// and an integer n. You should cycle through the choices
// starting at the beginning and counting up to N. Every
// time N is reached one choice should be removed. Continue
// this process counting to N and removing the choice at that
// count until only one choice is left. Return that choice.
// [A, B, C, D, E, F] n=3 returns B
// [A, B, C, D, E, F] n=4 returns F
function josephus(choices, n) {

}